#!/bin/bash
 
LOGGER="/usr/bin/logger"
  
# Determine working directory
install_dir=`dirname $0`

# Uninstall existing copy of Sophos 8.x by checking for the
# Sophos Antivirus uninstaller package in /Library/Sophos Anti-Virus.
# If present, the uninstallation process is run.
  
if [ -d "/Library/Sophos Anti-Virus/Remove Sophos Anti-Virus.pkg" ]; then
     ${LOGGER} "Sophos AV present on Mac. Uninstalling before installing new copy."
     /usr/sbin/installer -pkg "/Library/Sophos Anti-Virus/Remove Sophos Anti-Virus.pkg" -target /
elif [ -d "/Library/Application Support/Sophos Anti-Virus/Remove Sophos Anti-Virus.pkg" ]; then
     ${LOGGER} "Sophos AV present on Mac. Uninstalling before installing new copy."
     /usr/sbin/installer -pkg "/Library/Application Support/Sophos Anti-Virus/Remove Sophos Anti-Virus.pkg" -target /   
else
   ${LOGGER} "Sophos Anti-Virus 8.x Uninstaller Not Present"
fi
 
# Uninstall existing copy of Sophos 9.0 Stand Alone by checking for the InstallationDeployer application
# in /Library/Application\ Support/Sophos/opm-sa/Installer.app/Contents/MacOS. If present, the
# uninstallation process is run.
 
if [[ -f "/Library/Application\ Support/Sophos/opm-sa/Installer.app/Contents/MacOS/InstallationDeployer" ]]; then
   ${LOGGER} "Sophos AV present on Mac. Uninstalling before installing new copy."
   "/Library/Application\ Support/Sophos/opm-sa/Installer.app/Contents/MacOS/InstallationDeployer" --remove
else
   ${LOGGER} "Sophos Anti-Virus 9.x Uninstaller Not Present"
fi

# Uninstall existing copy of Sophos 9.0 Enterprise by checking for the InstallationDeployer application
# in /Library/Application\ Support/Sophos/opm/Installer.app/Contents/MacOS/InstallationDeployer. If present, the
# uninstallation process is run.

if [[ -f "/Library/Application\ Support/Sophos/opm/Installer.app/Contents/MacOS/InstallationDeployer" ]]; then
   ${LOGGER} "Sophos AV Enterprise present on Mac. Uninstalling before installing new copy."
   "/Library/Application\ Support/Sophos/opm/Installer.app/Contents/MacOS/InstallationDeployer" --remove
else
   ${LOGGER} "Sophos Anti-Virus 9.0 Uninstaller Not Present"
fi

# Uninstall existing copy of Sophos 9.1 Enterprise by checking for the InstallationDeployer application
# in /Library/Application\ Support/Sophos/opm/Installer.app/Contents/MacOS/tools/InstallationDeployer. If present, the
# uninstallation process is run.

if [[ -f "/Library/Application\ Support/Sophos/opm/Installer.app/Contents/MacOS/tools/InstallationDeployer" ]]; then
   ${LOGGER} "Sophos AV Enterprise present on Mac. Uninstalling before installing new copy."
   "/Library/Application\ Support/Sophos/opm/Installer.app/Contents/MacOS/tools/InstallationDeployer" --remove
else
   ${LOGGER} "Sophos Anti-Virus 9.1 Uninstaller Not Present"
fi
 
# Install Sophos Anti-Virus 9.2
# "/usr/local/sophos/Sophos Installer.app/Contents/MacOS/InstallationDeployer" --install
 
"/usr/local/sophos/Sophos Installer.app/Contents/MacOS/tools/InstallationDeployer" --install
  
# Restart SophosAutoUpdate to force the Sophos AutoUpdate process
# to read the settings stored in /Library/Sophos Anti-Virus/com.sophos.sau.plist
 
killall -HUP SophosAutoUpdate
 
# Cleanup
 
cd /
rm -rf /private/tmp/sophos_install
  
exit 0